# Lord of the Rings SDK

Python SDK for the Lord of the Rings API

## Installation

To install the Lord of the Rings SDK, you can use pip:

    pip install lord_of_the_rings_sdk

USAGE

Here's an example of how to use the Lord Of The Rings SDK:

from lord_of_the_rings.lord_of_the_rings_client import LordOfTheRingsClient

bearer_token = "user_provided_bearer_token"

lotr_client = LordOfTheRingsClient(bearer_token)

# Example usage:
movies_data = lotr_client.get_movie()
movie_data = lotr_client.get_movie(movie_id=1)
quotes_data = lotr_client.get_quote()
quote_data = lotr_client.get_quote(quote_id=1)

Make sure to replace "user_provided_bearer_token" with the actual bearer token you obtain from the Lord of the Rings API.